--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "GAA";
--
-- Name: GAA; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "GAA" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE "GAA" OWNER TO postgres;

\unrestrict (null)
\connect "GAA"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE "GAA"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "GAA" IS 'Banco de dados da ong Grupo Amparo e Alivio';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: area_atuacao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.area_atuacao (
    id_area integer NOT NULL,
    nome_area character varying(100) NOT NULL
);


ALTER TABLE public.area_atuacao OWNER TO postgres;

--
-- Name: area_atuacao_id_area_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.area_atuacao_id_area_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.area_atuacao_id_area_seq OWNER TO postgres;

--
-- Name: area_atuacao_id_area_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.area_atuacao_id_area_seq OWNED BY public.area_atuacao.id_area;


--
-- Name: disponibilidade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.disponibilidade (
    id_disponibilidade integer NOT NULL,
    id_voluntario integer,
    dia_semana character varying(20) NOT NULL,
    horario time without time zone NOT NULL
);


ALTER TABLE public.disponibilidade OWNER TO postgres;

--
-- Name: disponibilidade_id_disponibilidade_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.disponibilidade_id_disponibilidade_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.disponibilidade_id_disponibilidade_seq OWNER TO postgres;

--
-- Name: disponibilidade_id_disponibilidade_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.disponibilidade_id_disponibilidade_seq OWNED BY public.disponibilidade.id_disponibilidade;


--
-- Name: telefone_voluntario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telefone_voluntario (
    id_telefone_voluntario integer NOT NULL,
    id_voluntario integer,
    telefone_residencial character varying(20),
    telefone_pessoal character varying(20) NOT NULL,
    telefone_consultorio character varying(20)
);


ALTER TABLE public.telefone_voluntario OWNER TO postgres;

--
-- Name: telefone_voluntario_id_telefone_voluntario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.telefone_voluntario_id_telefone_voluntario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.telefone_voluntario_id_telefone_voluntario_seq OWNER TO postgres;

--
-- Name: telefone_voluntario_id_telefone_voluntario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.telefone_voluntario_id_telefone_voluntario_seq OWNED BY public.telefone_voluntario.id_telefone_voluntario;


--
-- Name: voluntario_area; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.voluntario_area (
    id_voluntario_area integer NOT NULL,
    id_voluntario integer,
    id_area integer
);


ALTER TABLE public.voluntario_area OWNER TO postgres;

--
-- Name: voluntario_area_id_voluntario_area_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.voluntario_area_id_voluntario_area_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.voluntario_area_id_voluntario_area_seq OWNER TO postgres;

--
-- Name: voluntario_area_id_voluntario_area_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.voluntario_area_id_voluntario_area_seq OWNED BY public.voluntario_area.id_voluntario_area;


--
-- Name: voluntarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.voluntarios (
    id_voluntario integer NOT NULL,
    nome character varying(100) NOT NULL,
    profissao character varying(100) NOT NULL,
    rg character varying(20) NOT NULL,
    cpf character varying(11) NOT NULL,
    registro_conselho character varying(20),
    cep integer NOT NULL,
    logradouro character varying NOT NULL,
    numero_residencial integer NOT NULL,
    bairro character varying NOT NULL,
    cidade character varying(100) NOT NULL,
    horas_semanais_disponiveis integer,
    data_cadastro date DEFAULT CURRENT_DATE
);


ALTER TABLE public.voluntarios OWNER TO postgres;

--
-- Name: voluntarios_id_voluntario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.voluntarios_id_voluntario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.voluntarios_id_voluntario_seq OWNER TO postgres;

--
-- Name: voluntarios_id_voluntario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.voluntarios_id_voluntario_seq OWNED BY public.voluntarios.id_voluntario;


--
-- Name: area_atuacao id_area; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.area_atuacao ALTER COLUMN id_area SET DEFAULT nextval('public.area_atuacao_id_area_seq'::regclass);


--
-- Name: disponibilidade id_disponibilidade; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disponibilidade ALTER COLUMN id_disponibilidade SET DEFAULT nextval('public.disponibilidade_id_disponibilidade_seq'::regclass);


--
-- Name: telefone_voluntario id_telefone_voluntario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone_voluntario ALTER COLUMN id_telefone_voluntario SET DEFAULT nextval('public.telefone_voluntario_id_telefone_voluntario_seq'::regclass);


--
-- Name: voluntario_area id_voluntario_area; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voluntario_area ALTER COLUMN id_voluntario_area SET DEFAULT nextval('public.voluntario_area_id_voluntario_area_seq'::regclass);


--
-- Name: voluntarios id_voluntario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voluntarios ALTER COLUMN id_voluntario SET DEFAULT nextval('public.voluntarios_id_voluntario_seq'::regclass);


--
-- Data for Name: area_atuacao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.area_atuacao (id_area, nome_area) FROM stdin;
\.
COPY public.area_atuacao (id_area, nome_area) FROM '$$PATH$$/4893.dat';

--
-- Data for Name: disponibilidade; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.disponibilidade (id_disponibilidade, id_voluntario, dia_semana, horario) FROM stdin;
\.
COPY public.disponibilidade (id_disponibilidade, id_voluntario, dia_semana, horario) FROM '$$PATH$$/4897.dat';

--
-- Data for Name: telefone_voluntario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telefone_voluntario (id_telefone_voluntario, id_voluntario, telefone_residencial, telefone_pessoal, telefone_consultorio) FROM stdin;
\.
COPY public.telefone_voluntario (id_telefone_voluntario, id_voluntario, telefone_residencial, telefone_pessoal, telefone_consultorio) FROM '$$PATH$$/4891.dat';

--
-- Data for Name: voluntario_area; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.voluntario_area (id_voluntario_area, id_voluntario, id_area) FROM stdin;
\.
COPY public.voluntario_area (id_voluntario_area, id_voluntario, id_area) FROM '$$PATH$$/4895.dat';

--
-- Data for Name: voluntarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.voluntarios (id_voluntario, nome, profissao, rg, cpf, registro_conselho, cep, logradouro, numero_residencial, bairro, cidade, horas_semanais_disponiveis, data_cadastro) FROM stdin;
\.
COPY public.voluntarios (id_voluntario, nome, profissao, rg, cpf, registro_conselho, cep, logradouro, numero_residencial, bairro, cidade, horas_semanais_disponiveis, data_cadastro) FROM '$$PATH$$/4889.dat';

--
-- Name: area_atuacao_id_area_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.area_atuacao_id_area_seq', 1, false);


--
-- Name: disponibilidade_id_disponibilidade_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.disponibilidade_id_disponibilidade_seq', 1, false);


--
-- Name: telefone_voluntario_id_telefone_voluntario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.telefone_voluntario_id_telefone_voluntario_seq', 1, false);


--
-- Name: voluntario_area_id_voluntario_area_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.voluntario_area_id_voluntario_area_seq', 1, false);


--
-- Name: voluntarios_id_voluntario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.voluntarios_id_voluntario_seq', 1, false);


--
-- Name: area_atuacao area_atuacao_nome_area_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.area_atuacao
    ADD CONSTRAINT area_atuacao_nome_area_key UNIQUE (nome_area);


--
-- Name: area_atuacao area_atuacao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.area_atuacao
    ADD CONSTRAINT area_atuacao_pkey PRIMARY KEY (id_area);


--
-- Name: disponibilidade disponibilidade_id_voluntario_dia_semana_horario_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disponibilidade
    ADD CONSTRAINT disponibilidade_id_voluntario_dia_semana_horario_key UNIQUE (id_voluntario, dia_semana, horario);


--
-- Name: disponibilidade disponibilidade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disponibilidade
    ADD CONSTRAINT disponibilidade_pkey PRIMARY KEY (id_disponibilidade);


--
-- Name: telefone_voluntario telefone_voluntario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone_voluntario
    ADD CONSTRAINT telefone_voluntario_pkey PRIMARY KEY (id_telefone_voluntario);


--
-- Name: voluntario_area voluntario_area_id_voluntario_id_area_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voluntario_area
    ADD CONSTRAINT voluntario_area_id_voluntario_id_area_key UNIQUE (id_voluntario, id_area);


--
-- Name: voluntario_area voluntario_area_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voluntario_area
    ADD CONSTRAINT voluntario_area_pkey PRIMARY KEY (id_voluntario_area);


--
-- Name: voluntarios voluntarios_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voluntarios
    ADD CONSTRAINT voluntarios_cpf_key UNIQUE (cpf);


--
-- Name: voluntarios voluntarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voluntarios
    ADD CONSTRAINT voluntarios_pkey PRIMARY KEY (id_voluntario);


--
-- Name: disponibilidade disponibilidade_id_voluntario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disponibilidade
    ADD CONSTRAINT disponibilidade_id_voluntario_fkey FOREIGN KEY (id_voluntario) REFERENCES public.voluntarios(id_voluntario) ON DELETE CASCADE;


--
-- Name: telefone_voluntario telefone_voluntario_id_voluntario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone_voluntario
    ADD CONSTRAINT telefone_voluntario_id_voluntario_fkey FOREIGN KEY (id_voluntario) REFERENCES public.voluntarios(id_voluntario) ON DELETE CASCADE;


--
-- Name: voluntario_area voluntario_area_id_area_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voluntario_area
    ADD CONSTRAINT voluntario_area_id_area_fkey FOREIGN KEY (id_area) REFERENCES public.area_atuacao(id_area) ON DELETE CASCADE;


--
-- Name: voluntario_area voluntario_area_id_voluntario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voluntario_area
    ADD CONSTRAINT voluntario_area_id_voluntario_fkey FOREIGN KEY (id_voluntario) REFERENCES public.voluntarios(id_voluntario) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

